bash scripts/build-development.sh &
bash scripts/serve.sh