(node_modules/.bin/tslint -c tslint.json  .src/**/*.ts{,x} &&
echo "No lint errors found!")