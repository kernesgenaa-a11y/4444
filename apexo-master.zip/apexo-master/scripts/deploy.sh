bash scripts/build-production.sh
bash scripts/upload.sh