export const colors = {
	green: [ '#4caf50', '#81c784', '#a5d6a7' ],
	blue: [ '#0d47a1', '#2196f3', '#64b5f6' ],
	violet: [ '#1a237e', '#3F51B5', '#9FA8DA' ],
	orange: [ '#D84315', '#FF5722', '#FFAB91' ],
	purple: [ '#e91e63', '#ec407a', '#f48fb1' ],
	yellow: [ '#fbc02d', '#ffd54f', '#ffe082' ],
	greenish: [ '#00796b', '#26a69a', '#80cbc4' ]
};
