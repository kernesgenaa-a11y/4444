export const statsNamespace = "statistics";
