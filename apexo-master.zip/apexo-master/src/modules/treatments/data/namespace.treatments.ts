export const treatmentsNamespace = "treatments";
