export const patientsNamespace = "patients";
