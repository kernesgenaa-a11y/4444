export const gender: {
	male: "male";
	female: "female";
} = { male: "male", female: "female" };
