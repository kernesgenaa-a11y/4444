export const prescriptionItemForm = {
	ampoule: "ampoule",
	capsule: "capsule",
	tablet: "tablet",
	pill: "pill",
	gel: "gel",
	spray: "spray",
	lotion: "lotion",
	ointment: "ointment",
	syrup: "syrup",
	powder: "powder",
	mouthwash: "mouthwash",
	suspension: "suspension",
	toothpaste: "toothpaste"
};
