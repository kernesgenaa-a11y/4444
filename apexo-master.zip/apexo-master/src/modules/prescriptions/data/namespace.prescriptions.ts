export const prescriptionsNamespace = "prescriptions";
