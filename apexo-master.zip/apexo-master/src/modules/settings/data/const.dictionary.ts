export const dictionary = {
	hourlyRate: "hourlyRate",
	currencySymbol: "currencySymbol",
	module_prescriptions: "module_prescriptions",
	module_orthodontics: "module_orthodontics",
	module_statistics: "module_statistics",
	module_labwork: "module_labwork",
	time_tracking: "time_tracking",
	dropbox_accessToken: "dropbox_accessToken",
	lang: "lang",
	date_format: "date_format",
	weekend_num: "weekend_num",
};
