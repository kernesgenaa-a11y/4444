export const labworkNamespace = "labwork";
