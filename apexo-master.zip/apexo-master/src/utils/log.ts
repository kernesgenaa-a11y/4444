export function log(...args: any) {
	return console.log(...args);
}
